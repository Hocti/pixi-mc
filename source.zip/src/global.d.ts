declare global {
    type int=number;
    type uint=number;
}
export {};